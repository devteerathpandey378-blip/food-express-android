FOOD EXPRESS ANDROID PROJECT (प्रारंभिक APK wrapper)

इस ZIP में आपके मौजूदा Food Express Version 2 HTML/PWA को एक साधारण Android WebView ऐप में पैक करने का Android source project है। यह अभी तैयार APK नहीं है। APK बनाने के लिए इसे GitHub पर अपलोड करके Actions workflow चलाना होगा।

मोबाइल से APK बनाने के चरण:
1. GitHub पर लॉगिन/साइन अप करें और नया खाली repository बनाएं: food-express-android
2. इस ZIP को extract करें। इसके अंदर की सभी files/folders repository के root में upload करें (ZIP को सीधे repository में रखने से build नहीं होगा)।
3. GitHub repository में Actions tab खोलें और “Build Food Express APK” workflow चुनें।
4. “Run workflow” दबाएं। Build पूरा होने पर workflow run के नीचे Artifacts में food-express-debug-apk.zip मिलेगा।
5. Artifact ZIP डाउनलोड करके extract करें। app-debug.apk को Android फोन में खोलें और install करें। फोन में “Install unknown apps” की अनुमति मांग सकता है।

महत्वपूर्ण सीमाएं:
- यह debug/test APK है, Play Store release APK नहीं। Play Store के लिए release signing, privacy policy, app listing और production testing चाहिए।
- मौजूदा HTML demo के features अभी demo/local browser storage तक सीमित हैं। यह APK अपने आप real orders, server database, restaurant/delivery dashboards, OTP, UPI payment या live tracking नहीं जोड़ता।
- Admin demo password सुरक्षित authentication नहीं है। असली ग्राहक डेटा या भुगतान शुरू करने से पहले server-side backend, database rules और payment gateway integration जरूरी हैं।
- अभी app का content APK के अंदर bundle है; वेबसाइट पर बाद में बदलाव करने से APK अपने आप update नहीं होगा।
